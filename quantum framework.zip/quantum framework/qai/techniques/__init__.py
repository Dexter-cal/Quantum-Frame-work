"""
qai.techniques -- the technique registry.

Built-ins are registered here exactly like a custom technique would be --
nothing special-cased, matching the design doc's "nothing is hardcoded" rule.
"""
from .base import Technique
from .regression import Regression
from .classifier import Classifier
from .decision_tree import DecisionTree
from .knn import KNearestNeighbors
from .kmeans import KMeans
from .pca import PCA
from .tabular_policy import TabularPolicy
from .svm import SVM
from .naive_bayes import NaiveBayes
from .perceptron import Perceptron
from .random_forest import RandomForest

REGISTRY = {
    "regression": Regression,
    "classifier": Classifier,
    "decision_tree": DecisionTree,
    "knn": KNearestNeighbors,
    "kmeans": KMeans,
    "pca": PCA,
    "tabular_policy": TabularPolicy,
    "svm": SVM,
    "naive_bayes": NaiveBayes,
    "perceptron": Perceptron,
    "random_forest": RandomForest,
}

SUPERVISED = ["regression", "classifier", "decision_tree", "knn", "svm",
              "naive_bayes", "perceptron", "random_forest"]
UNSUPERVISED = ["kmeans", "pca"]


def register_technique(name: str, cls):
    """Let a user register their OWN technique the same way built-ins are
    registered -- real, working extensibility, not just a design promise."""
    if not issubclass(cls, Technique):
        raise TypeError("Custom techniques must extend qai.techniques.Technique")
    REGISTRY[name] = cls


def get_technique(name: str):
    if name not in REGISTRY:
        available = ", ".join(REGISTRY.keys())
        raise ValueError(f"Unknown technique '{name}'. Available: {available}")
    return REGISTRY[name]
