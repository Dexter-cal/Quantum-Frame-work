"""
qai -- functional Python prototype of the design doc's core pipeline.

    import qai
    model = qai.build(type="regression")
    model.train(X, y)
    model.predict(x)

Purpose: test whether the ERGONOMICS (not the compiler/language claims)
actually hold up against real data, fast, before investing in the harder
Rust/C compiler engineering.
"""
from .core import build, Model, logic, LogicError, CompatibilityError
from .core.logic import save_logic_source, load_logic_source
from .core.environment import GridWorld
from .core.dataset import Dataset
from .core.serve import serve, build_flask_app
from .core.pipeline import Pipeline
from .core.cross_validation import cross_validate, k_fold_split
from .core.ensemble import VotingEnsemble
from .techniques import register_technique, Technique
from .learning import get_learning_technique, LearningTechnique

__all__ = ["build", "Model", "register_technique", "Technique", "logic", "LogicError",
           "GridWorld", "get_learning_technique", "LearningTechnique", "CompatibilityError",
           "Dataset", "serve", "build_flask_app", "Pipeline", "cross_validate", "k_fold_split",
           "VotingEnsemble", "save_logic_source", "load_logic_source"]
__version__ = "0.1.0-prototype"
